# Personal web site
Simple web site made by me initially with HTML and CSS, in future i will implement some new functionalities star my repo =)

## License and how to use
Everything related to my personal work is under MIT licence.

## Web site template
The web site is made entirely by me =)

## CV Latex template
The latex CV template is awesome CV: https://github.com/posquit0/Awesome-CV

My version will be uploaded soon.
